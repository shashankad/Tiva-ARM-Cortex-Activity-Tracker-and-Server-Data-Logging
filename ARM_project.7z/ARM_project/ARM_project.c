//*****************************************************************************
//
// This is ARM_Project - the final academic project for Microporcessor systems
// An Accelerometer is connected to ADC input as follows
//ADC                 :	AIN0 = CH0 = PE3 connected to x - axis of accelerometer
//		   				AIN1 = CH1 = PE2 connected to y - axis of accelerometer
//		   				AIN2 = CH2 = PE1 connected to z - axis of accelerometer
//LEDs    			  : LED1 = PN1
//		   				LED2 = PN0
//   	   				LED3 = PF4
//		   				LED4 = PF0
//Vibrator or Vibmotor: PN4 connected to vibmotor
//Accelerometer       : +3.3V supply & gnd
//*****************************************************************************
//Author			  : Shashanka Doddamani
//ID				  : sxd148730@utdallas.edu
//Cell                : +1 4697746761
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "drivers/pinout.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "driverlib/adc.h"

//*****************************************************************************
//
//!
//!
//! Open a terminal with 115,200 8-N-1 for UART.
//  use python graph.py for python graph send x,y,z values
//  use server1.js, server2.js for ploting data in plotly server send only x values
//*****************************************************************************
// Store old X,Y,Z Values
uint32_t xValueOld[3]= {1,2,3};
uint32_t yValueOld[3]= {1,2,3};
uint32_t zValueOld[3]= {1,2,3};
// Store current X,YZ, value
uint32_t xValue;
uint32_t yValue;
uint32_t zValue;
// Count to trak iteration
uint32_t count=0;
// Variable for gesture recognition
uint32_t left=0;
uint32_t right=0;
//*****************************************************************************
//
// System clock rate in Hz.
//
//*****************************************************************************
uint32_t g_ui32SysClock;

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

//*****************************************************************************
//
// Configure the UART and its pins.  This must be called before UARTprintf().
//
//*****************************************************************************
void
ConfigureUART(void)
{
    //
    // Enable the GPIO Peripheral used by the UART.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Enable UART0
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    //
    // Configure GPIO Pins for UART mode.
    //
    ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
    ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioConfig(0, 115200, g_ui32SysClock);
}
//*****************************************************************************
//
// Turn off the LEDs and Vibmotor
//
//*****************************************************************************
void Turnoff(void)
{
	// Turn off D1,D2,D3,D4.
	GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, 0x0);
	GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 0x0);
	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, 0x0);
	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0, 0x0);
	 // Turn off the Vibmotor
	GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_4, 0x0);



}
//*****************************************************************************
//
// Turn on the LEDs and Vibmotor
//
//*****************************************************************************
void Turnon(void)
{
	// Turn on D1,D2,D3,D4.
	GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, GPIO_PIN_1);
	GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, GPIO_PIN_0);
	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0, GPIO_PIN_0);
	 // Turn on the Vibmotor
	GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_4, GPIO_PIN_4);
}
//*****************************************************************************
//
// main program
//
//*****************************************************************************
int
main(void)
{
    //
    // Run from the PLL at 120 MHz.
    //
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
                SYSCTL_CFG_VCO_480), 120000000);

    //
    // Configure the device pins.
    //
    PinoutSet(false, false);

    //
    // Enable the GPIO port that is used for the on-board LED.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    //
    // Enable the GPIO pin for the LED1 (PN1), LED2(PN0), LED3(PF4), LED4(PF0) and Vibmotor at PN4.  Set the direction as output, and
    // enable the GPIO pin for digital function.
    //PN1
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);
    //PN0
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);
    //PN4
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_4);
    //PF4
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4);
    //PF0
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_0);


    //
    // Initialize the UART.
    //
    ConfigureUART();


    //
    // We are finished.  Hang around flashing D1.
    //

    //
    // This array is used for storing the data read from the ADC FIFO. It
    // must be as large as the FIFO for the sequencer in use.  This example
    // uses sequence 3 which has a FIFO depth of 1.  If another sequence
    // was used with a deeper FIFO, then the array size must be changed.
    //
    uint32_t pui32ADC0Value[3];

    //
    // The ADC0 peripheral must be enabled for use.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);



    //
   // Enable sample sequence 3 with a processor signal trigger.  Sequence 3
   // will do a single sample when the processor sends a singal to start the
   // conversion.  Each ADC module has 4 programmable sequences, sequence 0
   // to sequence 3.  This example is arbitrarily using sequence 3.
   //
   ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);

   //
   // Configure step 0 on sequence 3.  Sample the temperature sensor
    // (ADC_CTL_TS) and configure the interrupt flag (ADC_CTL_IE) to be set
    // when the sample is done.  Tell the ADC logic that this is the last
    // conversion on sequence 3 (ADC_CTL_END).  Sequence 3 has only one
    // programmable step.  Sequence 1 and 2 have 4 steps, and sequence 0 has
    // 8 programmable steps.  Since we are only doing a single conversion using
    // sequence 3 we will only configure step 0.  For more information on the
    // ADC sequences and steps, reference the datasheet.

    //AIN0, AIN1, AIN2 is connected to X,Y,Z axis respectively
    ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH0
                                               );
    ADCSequenceStepConfigure(ADC0_BASE, 0, 1, ADC_CTL_CH1
                                                );

    ADCSequenceStepConfigure(ADC0_BASE, 0, 2, ADC_CTL_CH2 | ADC_CTL_IE |
                                      ADC_CTL_END);
             //
    // Since sample sequence 3 is now configured, it must be enabled.
    //
    ADCSequenceEnable(ADC0_BASE, 0);
    //
   // Clear the interrupt status flag.  This is done to make sure the
   // interrupt flag is cleared before we sample.
   //
   ADCIntClear(ADC0_BASE, 0);

    while(1)
    {



                //
                // Trigger the ADC conversion.
                //
                ADCProcessorTrigger(ADC0_BASE, 0);

                //

                // Wait for conversion to be completed.
                        //
                while(!ADCIntStatus(ADC0_BASE, 0, false))
                {
                }
                //



                // Clear the ADC interrupt flag.
                //
                ADCIntClear(ADC0_BASE, 0);

                //
                // Read ADC Value.
                //
                ADCSequenceDataGet(ADC0_BASE, 0, pui32ADC0Value);


                // Store X,Y,Z values
                xValue = pui32ADC0Value[0]/10;
                yValue = pui32ADC0Value[1]/10;
                zValue = pui32ADC0Value[2]/10;

                // send the x,y,x axis reading to PC
//*****************************************************************************
                // Send only x for server2.js
                // UARTprintf("%d\n", xValue);
//*****************************************************************************
                // Send x,y,z for python graph.py
                UARTprintf("%d,%d,%d\n", xValue, yValue, zValue);
//*****************************************************************************
                // Store old X,YZ, vlues
                                switch(count)
                                {
                                case 1: xValueOld[0] = xValue;
                                		break;
                                case 2: xValueOld[1] = xValue;
                                        break;
                                case 3: xValueOld[2] = xValue;
                                        count = 0;
                                        break;
                                default:
                                  		break;
                                }

                                // Update count
                                count = count+1;

                                if(xValueOld[0]==xValueOld[1] )
                                   {
                                     if(xValueOld[1]==xValueOld[2])
                                     {
                                    	 Turnon();
                                    	 //UARTprintf("You are idle, please perform the gesture\n");
                                    	         //

                                     }
                                     else
                                     {
                                    	 if(left & right)
                                    	 {
                                    	 Turnoff();
                                    	 left =0;
                                    	 right =0;
                                    	 }
                                    	 // Delay for a bit.
                                    	 //
                                    	 SysCtlDelay(g_ui32SysClock / 10/3);
                                     }
                                   }
                                   else
                                   {
                                	   if(left&right)
                                	   {
                                	   Turnoff();
                                	   left =0;
                                	   right =0;
                                	   }
                                	   // Delay for a bit.

                                       SysCtlDelay(g_ui32SysClock / 10 / 3);
                                   }

                                // Gesture recognition
                                if(xValue>235)
                                {
                                	// Now user turned left
                                	left = 1;
                                	//UARTprintf("You twisted your wrist towards left, now twist towards right\n");
                                }
                                if(xValue<175)
                                {
                                	// Now user turned right
                                	right = 1;
                                	//UARTprintf("You twisted your wrist towards right. You are awake!\n");
                                }
                                //0.6 sec
                                SysCtlDelay(g_ui32SysClock/5);


    }
}
